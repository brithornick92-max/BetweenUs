import React, { createContext, useContext, useEffect, useState, useMemo } from "react";
import { useColorScheme } from "react-native";
import {
  DARK_PALETTE,
  LIGHT_PALETTE,
  getGradients,
  getShadows,
  getNavigationTheme,
} from "../utils/theme";
import { settingsStorage } from "../utils/storage";

const ThemeContext = createContext(null);

const THEME_MODES = ["auto", "dark", "light"];
const DEFAULT_THEME_MODE = "dark";

export const useTheme = () => {
  const context = useContext(ThemeContext);
  const systemColorScheme = useColorScheme();

  if (!context) {
    const fallbackPalette = DARK_PALETTE;
    return {
      themeMode: DEFAULT_THEME_MODE,
      setThemeMode: () => {},
      isDark: true,
      colors: fallbackPalette,
      gradients: getGradients(fallbackPalette),
      shadows: getShadows(fallbackPalette),
      navigationTheme: getNavigationTheme(fallbackPalette),
    };
  }

  return context;
};

export const ThemeProvider = ({ children }) => {
  const systemColorScheme = useColorScheme();
  const [themeMode, setThemeModeState] = useState(DEFAULT_THEME_MODE);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const stored = await settingsStorage.getThemeMode(null);
        if (active && stored && THEME_MODES.includes(stored)) {
          setThemeModeState(stored);
        }
      } catch {
        // ignore
      } finally {
        if (active) setLoaded(true);
      }
    };
    load();
    return () => { active = false; };
  }, []);

  const setThemeMode = async (mode) => {
    if (!THEME_MODES.includes(mode)) return;
    setThemeModeState(mode);
    try {
      await settingsStorage.setThemeMode(mode);
    } catch {
      // ignore
    }
  };

  // No longer polling time; uses systemColorScheme hook natively

  const palette = useMemo(() => {
    if (themeMode === "auto") return systemColorScheme === "dark" ? DARK_PALETTE : LIGHT_PALETTE;
    return themeMode === "dark" ? DARK_PALETTE : LIGHT_PALETTE;
  }, [themeMode, systemColorScheme]);

  const isDark = useMemo(() => palette === DARK_PALETTE, [palette]);

  const gradients = useMemo(() => getGradients(palette), [palette]);
  const shadows = useMemo(() => getShadows(palette), [palette]);
  const navigationTheme = useMemo(() => getNavigationTheme(palette), [palette]);

  const value = useMemo(
    () => ({
      themeMode,
      setThemeMode,
      isDark,
      colors: palette,
      gradients,
      shadows,
      navigationTheme,
      loaded,
    }),
    [themeMode, isDark, palette, gradients, shadows, navigationTheme, loaded]
  );

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};
