import LocalStorageService from '../LocalStorageService';

class LocalEngine {
  async initialize() {
    return true;
  }

  createAccount(email, password, displayName) {
    return LocalStorageService.createAccount(email, password, displayName);
  }

  hydrateRemoteAccount(params) {
    return LocalStorageService.hydrateRemoteAccount(params);
  }

  signInWithEmailAndPassword(email, password) {
    return LocalStorageService.signInWithEmailAndPassword(email, password);
  }

  updatePasswordForEmail(email, password) {
    return LocalStorageService.updatePasswordForEmail(email, password);
  }

  signOut(scope) {
    return LocalStorageService.signOut(scope);
  }

  onAuthStateChanged(callback) {
    return LocalStorageService.onAuthStateChanged(callback);
  }

  getUserDocument(userId) {
    return LocalStorageService.getUserDocument(userId);
  }

  updateUserDocument(userId, updates) {
    return LocalStorageService.updateUserDocument(userId, updates);
  }

  deleteUserDocument(userId) {
    return LocalStorageService.deleteUserDocument(userId);
  }

  getPrompts(filters = {}) {
    return LocalStorageService.getPrompts(filters);
  }

  getDates(filters = {}) {
    return LocalStorageService.getDates(filters);
  }

  saveMemory(userId, memoryData) {
    return LocalStorageService.saveMemory(userId, memoryData);
  }

  getUserMemories(userId) {
    return LocalStorageService.getUserMemories(userId);
  }

  updateMemory(memoryId, updates) {
    return LocalStorageService.updateMemory(memoryId, updates);
  }

  deleteMemory(memoryId) {
    return LocalStorageService.deleteMemory(memoryId);
  }

  linkPartner(userId, partnerCode) {
    return LocalStorageService.linkPartner(userId, partnerCode);
  }

  unlinkPartner(userId) {
    return LocalStorageService.unlinkPartner(userId);
  }
}

export default new LocalEngine();
