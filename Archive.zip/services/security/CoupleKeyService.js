/**
 * CoupleKeyService.js — X25519 ECDH key exchange for Between Us
 *
 * Flow:
 *   1. Each device generates an X25519 keypair (nacl.box.keyPair).
 *   2. Inviter embeds their PUBLIC key in the QR code.
 *   3. Scanner scans QR, derives shared secret via
 *      nacl.box.before(inviterPublicKey, scannerSecretKey).
 *   4. Scanner's PUBLIC key is sent to Supabase (stored encrypted)
 *      so the inviter can derive the same shared secret.
 *   5. Shared secret is run through HKDF (SHA-512 based) to produce
 *      the final 32-byte couple symmetric key for secretbox.
 *
 * Multi-device:
 *   The couple key is wrapped (encrypted) using nacl.box for each
 *   device's public key. Adding a 2nd device = wrapping the existing
 *   couple key to the new device's pubkey. No re-pairing needed.
 *
 * Key storage (SecureStore):
 *   - Device keypair:  betweenus_device_kp       (64 bytes: secret‖public)
 *   - Couple key:      betweenus_couple_key_{id}  (32 bytes)
 *   - Key version:     betweenus_couple_kv_{id}   (integer, for rotation)
 */

import * as SecureStore from "expo-secure-store";
import nacl from "tweetnacl";
import naclUtil from "tweetnacl-util";

const COUPLE_KEY_PREFIX = "betweenus_couple_key_";
const COUPLE_KV_PREFIX = "betweenus_couple_kv_";
const DEVICE_KP_NAME = "betweenus_device_kp";
const SERVICE = "betweenus_couple";

const encode = naclUtil.encodeBase64;
const decode = naclUtil.decodeBase64;

// ─── Device keypair (X25519) ────────────────────────────────────────

let _deviceKpCache = null;

const CoupleKeyService = {
  /**
   * Get or create a persistent X25519 keypair for this device.
   * The keypair is stored as secret‖public (64 bytes) in SecureStore.
   * @returns {{ publicKey: Uint8Array, secretKey: Uint8Array }}
   */
  async getDeviceKeyPair() {
    if (_deviceKpCache) return _deviceKpCache;

    const stored = await SecureStore.getItemAsync(DEVICE_KP_NAME, {
      keychainService: SERVICE,
      keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
    });

    if (stored) {
      try {
        const bytes = decode(stored);
        if (bytes.length === 64) {
          _deviceKpCache = {
            secretKey: bytes.slice(0, 32),
            publicKey: bytes.slice(32, 64),
          };
          return _deviceKpCache;
        }
      } catch (e) {
        // Keypair corrupted — report before regenerating
        const CrashReporting = require('../CrashReporting').default;
        CrashReporting.captureException(
          new Error('CoupleKeyService: device keypair corrupted, regenerating — existing couple key wrapping will break'),
          { keyName: DEVICE_KP_NAME, error: e?.message }
        );
      }
    }

    // Generate fresh keypair
    const kp = nacl.box.keyPair();
    // Store as secret‖public
    const combined = new Uint8Array(64);
    combined.set(kp.secretKey, 0);
    combined.set(kp.publicKey, 32);
    await SecureStore.setItemAsync(DEVICE_KP_NAME, encode(combined), {
      keychainService: SERVICE,
      keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
    });
    _deviceKpCache = kp;
    return kp;
  },

  /**
   * Get this device's public key (base64) for embedding in QR codes.
   */
  async getDevicePublicKeyB64() {
    const kp = await this.getDeviceKeyPair();
    return encode(kp.publicKey);
  },

  // ─── Key exchange (ECDH + HKDF) ─────────────────────────────────

  /**
   * HMAC-SHA-512 using tweetnacl's nacl.hash (SHA-512).
   * Implements RFC 2104 HMAC construction.
   *
   * @param {Uint8Array} key — HMAC key
   * @param {Uint8Array} message — message to authenticate
   * @returns {Uint8Array} — 64-byte HMAC-SHA-512 output
   */
  _hmacSha512(key, message) {
    const BLOCK_SIZE = 128; // SHA-512 block size
    let k = key;
    // If key is longer than block size, hash it first
    if (k.length > BLOCK_SIZE) {
      k = nacl.hash(k);
    }
    // Pad key to block size
    const paddedKey = new Uint8Array(BLOCK_SIZE);
    paddedKey.set(k);

    // Inner and outer pads
    const ipad = new Uint8Array(BLOCK_SIZE);
    const opad = new Uint8Array(BLOCK_SIZE);
    for (let i = 0; i < BLOCK_SIZE; i++) {
      ipad[i] = paddedKey[i] ^ 0x36;
      opad[i] = paddedKey[i] ^ 0x5c;
    }

    // inner = SHA-512(ipad || message)
    const innerInput = new Uint8Array(BLOCK_SIZE + message.length);
    innerInput.set(ipad, 0);
    innerInput.set(message, BLOCK_SIZE);
    const innerHash = nacl.hash(innerInput);

    // outer = SHA-512(opad || inner)
    const outerInput = new Uint8Array(BLOCK_SIZE + innerHash.length);
    outerInput.set(opad, 0);
    outerInput.set(innerHash, BLOCK_SIZE);
    return nacl.hash(outerInput);
  },

  /**
   * HKDF-SHA-512 (RFC 5869) — Extract-then-Expand.
   *
   * Replaces the previous non-standard SHA-512 truncation.
   * Uses proper HMAC-SHA-512 for both extract and expand phases.
   *
   * @param {Uint8Array} ikm — input keying material (X25519 shared secret)
   * @param {string} info — domain separation / context string
   * @param {Uint8Array} [salt] — optional salt (defaults to 64 zero bytes per RFC)
   * @param {number} [length=32] — output key length in bytes
   * @returns {Uint8Array} — derived key
   */
  _hkdf(ikm, info = "betweenus-couple-key-v2", salt = null, length = 32) {
    // 1. Extract: PRK = HMAC-SHA-512(salt, IKM)
    const effectiveSalt = salt || new Uint8Array(64); // 64 zero bytes for SHA-512
    const prk = this._hmacSha512(effectiveSalt, ikm);

    // 2. Expand: OKM = T(1) || T(2) || ... truncated to `length`
    const infoBytes = naclUtil.decodeUTF8(info);
    const hashLen = 64; // SHA-512 output
    const n = Math.ceil(length / hashLen);
    const okm = new Uint8Array(n * hashLen);
    let prev = new Uint8Array(0);

    for (let i = 1; i <= n; i++) {
      const input = new Uint8Array(prev.length + infoBytes.length + 1);
      input.set(prev, 0);
      input.set(infoBytes, prev.length);
      input[input.length - 1] = i;
      prev = this._hmacSha512(prk, input);
      okm.set(prev, (i - 1) * hashLen);
    }

    return okm.slice(0, length);
  },

  /**
   * KDF wrapper — delegates to HKDF-SHA-512 (RFC 5869).
   *
   * @param {Uint8Array} ikm — input keying material (X25519 shared secret)
   * @param {string} info — domain separation string
   * @returns {Uint8Array} — 32-byte derived key
   */
  _kdf(ikm, info = "betweenus-couple-key-v2") {
    return this._hkdf(ikm, info);
  },

  /**
   * Derive the couple symmetric key from an X25519 shared secret.
   *
   * @param {Uint8Array} partnerPublicKey — the other device's X25519 public key
   * @returns {Promise<Uint8Array>} — 32-byte symmetric key for secretbox
   */
  async deriveFromKeyExchange(partnerPublicKey) {
    const kp = await this.getDeviceKeyPair();
    // X25519 ECDH: both sides compute the same shared secret
    const rawShared = nacl.box.before(partnerPublicKey, kp.secretKey);
    // Run through KDF to get the final couple key
    return this._kdf(rawShared);
  },

  // ─── Multi-device key wrapping ─────────────────────────────────

  /**
   * Wrap (encrypt) the couple key for a specific device's public key.
   * Uses nacl.box (X25519 + XSalsa20-Poly1305 authenticated encryption).
   *
   * @param {Uint8Array} coupleKey — the 32-byte couple symmetric key
   * @param {Uint8Array} targetPublicKey — the device's X25519 public key
   * @returns {Promise<string>} — JSON envelope { n, c } (nonce + ciphertext, base64)
   */
  async wrapKeyForDevice(coupleKey, targetPublicKey) {
    const kp = await this.getDeviceKeyPair();
    const nonce = nacl.randomBytes(nacl.box.nonceLength);
    const encrypted = nacl.box(coupleKey, nonce, targetPublicKey, kp.secretKey);
    return JSON.stringify({
      n: encode(nonce),
      c: encode(encrypted),
      from: encode(kp.publicKey),
    });
  },

  /**
   * Unwrap (decrypt) a couple key that was wrapped for this device.
   *
   * @param {string} wrappedJson — output from wrapKeyForDevice
   * @returns {Promise<Uint8Array|null>} — the 32-byte couple key, or null
   */
  async unwrapKeyForDevice(wrappedJson) {
    const kp = await this.getDeviceKeyPair();
    let parsed;
    try {
      parsed = typeof wrappedJson === "string" ? JSON.parse(wrappedJson) : wrappedJson;
    } catch {
      return null;
    }

    if (!parsed?.n || !parsed?.c || !parsed?.from) return null;

    const nonce = decode(parsed.n);
    const ciphertext = decode(parsed.c);
    const senderPublicKey = decode(parsed.from);

    const opened = nacl.box.open(ciphertext, nonce, senderPublicKey, kp.secretKey);
    return opened && opened.length === 32 ? opened : null;
  },

  // ─── Couple key storage ────────────────────────────────────────

  /**
   * Store the couple symmetric key in SecureStore.
   * @param {string} coupleId
   * @param {Uint8Array} keyBytes — 32-byte key
   * @param {number} version — key version (for rotation tracking)
   */
  async storeCoupleKey(coupleId, keyBytes, version = 1) {
    if (!keyBytes || keyBytes.length !== 32) {
      throw new Error("Invalid couple key: must be exactly 32 bytes");
    }
    const encoded = encode(keyBytes);
    await SecureStore.setItemAsync(
      `${COUPLE_KEY_PREFIX}${coupleId}`,
      encoded,
      { keychainService: SERVICE, keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK }
    );
    await SecureStore.setItemAsync(
      `${COUPLE_KV_PREFIX}${coupleId}`,
      String(version),
      { keychainService: SERVICE, keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK }
    );
    return true;
  },

  /**
   * Retrieve the couple symmetric key.
   * @returns {Uint8Array|null}
   */
  async getCoupleKey(coupleId) {
    if (!coupleId) return null;
    const stored = await SecureStore.getItemAsync(
      `${COUPLE_KEY_PREFIX}${coupleId}`,
      { keychainService: SERVICE, keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK }
    );
    if (!stored) return null;
    try {
      const bytes = decode(stored);
      if (bytes.length !== 32) return null;
      return bytes;
    } catch {
      return null;
    }
  },

  /**
   * Get the current key version (for envelope `kid` field).
   * @returns {number}
   */
  async getKeyVersion(coupleId) {
    if (!coupleId) return 0;
    const v = await SecureStore.getItemAsync(
      `${COUPLE_KV_PREFIX}${coupleId}`,
      { keychainService: SERVICE, keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK }
    );
    return v ? parseInt(v, 10) : 1;
  },

  /**
   * Rotate the couple key. Generates a new random 32-byte key,
   * stores it, and increments the version.
   *
   * @returns {{ key: Uint8Array, version: number }}
   */
  async rotateCoupleKey(coupleId) {
    const newKey = nacl.randomBytes(32);
    const oldVersion = await this.getKeyVersion(coupleId);
    const newVersion = oldVersion + 1;
    await this.storeCoupleKey(coupleId, newKey, newVersion);
    return { key: newKey, version: newVersion };
  },

  /**
   * Check if we have a valid couple key for the given coupleId.
   */
  async hasCoupleKey(coupleId) {
    const key = await this.getCoupleKey(coupleId);
    return key !== null;
  },

  /**
   * Clear the couple key and version (on unpair / account delete).
   */
  async clearCoupleKey(coupleId) {
    await SecureStore.deleteItemAsync(`${COUPLE_KEY_PREFIX}${coupleId}`, {
      keychainService: SERVICE,
    });
    await SecureStore.deleteItemAsync(`${COUPLE_KV_PREFIX}${coupleId}`, {
      keychainService: SERVICE,
    });
  },

  /**
   * Clear cached device keypair (sign-out / testing).
   */
  clearDeviceKeyPairCache() {
    _deviceKpCache = null;
  },
};

export default CoupleKeyService;
