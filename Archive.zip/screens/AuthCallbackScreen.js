/**
 * AuthCallbackScreen — High-end authentication bridge
 * Sexy Red Intimacy & Apple Editorial Updates Integrated.
 * * Handles tokens from deep-link URL fragments for Supabase Auth.
 */

import React, { useEffect, useState, useRef, useMemo } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ActivityIndicator, 
  TouchableOpacity, 
  Linking, 
  Platform, 
  StatusBar 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useTheme } from '../context/ThemeContext';
import { useEntitlements } from '../context/EntitlementsContext';
import SupabaseAuthService from '../services/supabase/SupabaseAuthService';
import extractAuthPayloadFromUrl from '../services/supabase/AuthCallbackPayload';
import { getSupabaseOrThrow } from '../config/supabase';
import StorageRouter from '../services/storage/StorageRouter';
import { cloudSyncStorage } from '../utils/storage';
import { SPACING, withAlpha } from '../utils/theme';
import Icon from '../components/Icon';

const SYSTEM_FONT = Platform.select({ ios: "System", android: "Roboto" });

export default function AuthCallbackScreen({ navigation }) {
  const { colors, isDark } = useTheme();
  const { isPremiumEffective: isPremium } = useEntitlements();
  
  const [status, setStatus] = useState('Signing you in...');
  const [hasSession, setHasSession] = useState(null);
  const [checking, setChecking] = useState(true);
  const [retryKey, setRetryKey] = useState(0);
  const timerRef = useRef(null);

  // ─── SEXY RED x APPLE EDITORIAL THEME MAP ───
  const t = useMemo(() => ({
    background: colors.background || '#070509', 
    surface: isDark ? '#131016' : '#FFFFFF',
    primary: colors.primary || '#D2121A', // Sexy Red
    text: colors.text || '#F2E9E6',
    subtext: isDark ? 'rgba(242,233,230,0.6)' : 'rgba(60, 60, 67, 0.6)',
    border: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)',
  }), [colors, isDark]);

  useEffect(() => {
    let active = true;

    const handleCallback = async () => {
      let sessionFound = false;
      try {
        const initialUrl = await Linking.getInitialURL();
        const payload = extractAuthPayloadFromUrl(initialUrl);

        let session = null;

        if (payload?.errorDescription) {
          throw new Error(payload.errorDescription);
        }

        if (payload?.access_token && payload?.refresh_token) {
          const supabase = getSupabaseOrThrow();
          const { data, error: setErr } = await supabase.auth.setSession({
            access_token: payload.access_token,
            refresh_token: payload.refresh_token,
          });
          if (setErr && __DEV__) console.warn('AuthCallback: setSession error:', setErr.message);
          session = data?.session || null;
        }

        if (!session) {
          session = await SupabaseAuthService.getSession();
        }

        const syncStatus = await cloudSyncStorage.getSyncStatus();
        const syncEnabled = !!syncStatus?.enabled && !!isPremium;

        if (!active) return;

        await StorageRouter.setSupabaseSession(session);
        await StorageRouter.configureSync({
          isPremium: !!isPremium,
          syncEnabled,
          supabaseSessionPresent: !!session,
        });

        sessionFound = !!session;
        setHasSession(sessionFound);
        setStatus(session ? 'Identity verified.' : 'The link may have expired.');
      } catch (error) {
        if (!active) return;
        setStatus(error?.message || 'Unable to complete sign-in.');
        setHasSession(false);
      } finally {
        if (!active) return;
        setChecking(false);
        if (sessionFound) {
          const t = setTimeout(() => {
            if (!active) return;
            navigation.navigate('SyncSetup');
          }, 800);
          // Store timer ID so cleanup can cancel it explicitly
          timerRef.current = t;
        }
      }
    };

    handleCallback();
    return () => {
      active = false;
      if (timerRef.current) { clearTimeout(timerRef.current); timerRef.current = null; }
    };
  }, [isPremium, navigation, retryKey]);

  const handleRetry = () => {
    setChecking(true);
    setHasSession(null);
    setStatus('Checking verification...');
    setRetryKey((k) => k + 1);
  };

  return (
    <View style={[styles.container, { backgroundColor: t.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      
      {/* Immersive Midnight Vignette */}
      <LinearGradient
        pointerEvents="none"
        colors={isDark ? ['#120206', t.background, t.background] : ['#FDF2F2', t.background, t.background]}
        style={StyleSheet.absoluteFill}
      />

      <SafeAreaView style={styles.safeArea}>
        <View style={[styles.card, { backgroundColor: t.surface, borderColor: t.border }]}>
          <View style={[styles.iconWrap, { backgroundColor: withAlpha(t.primary, 0.12) }]}>
            <Icon 
              name={hasSession === false ? "alert-circle-outline" : "finger-print-outline"} 
              size={32} 
              color={t.primary} 
            />
          </View>

          <View style={styles.textContainer}>
            <Text style={[styles.title, { color: t.text }]}>
              {checking ? 'Authenticating' : (hasSession ? 'Success' : 'Verification Failed')}
            </Text>
            <Text style={[styles.subtitle, { color: t.subtext }]}>{status}</Text>
          </View>

          {checking ? (
            <ActivityIndicator color={t.primary} style={styles.loader} />
          ) : (
            hasSession === false && (
              <TouchableOpacity 
                style={[styles.primaryButton, { backgroundColor: t.primary }]} 
                onPress={handleRetry} 
                activeOpacity={0.9}
              >
                <Text style={styles.primaryButtonText}>Retry Link</Text>
                <Icon name="refresh-outline" size={16} color="#FFFFFF" />
              </TouchableOpacity>
            )
          )}

          {hasSession && (
             <View style={[styles.indicator, { backgroundColor: t.primary }]} />
          )}
        </View>
        
        <Text style={[styles.footerText, { color: t.subtext }]}>
          Securely connecting your shared space.
        </Text>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
    paddingHorizontal: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    width: '100%',
    maxWidth: 400,
    borderRadius: 32, // Deep Apple Squircle
    padding: SPACING.xxl,
    alignItems: 'center',
    borderWidth: 1,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 20 },
        shadowOpacity: 0.2,
        shadowRadius: 40,
      },
      android: { elevation: 8 },
    }),
  },
  iconWrap: {
    width: 72,
    height: 72,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  textContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontFamily: SYSTEM_FONT,
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontFamily: SYSTEM_FONT,
    fontSize: 16,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 22,
  },
  loader: {
    marginTop: 8,
  },
  primaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: 56,
    borderRadius: 28, // Pill shape
    paddingHorizontal: 32,
    gap: 10,
    minWidth: 180,
  },
  primaryButtonText: {
    color: '#FFFFFF',
    fontFamily: SYSTEM_FONT,
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.3,
    textTransform: 'uppercase',
  },
  footerText: {
    position: 'absolute',
    bottom: 50,
    fontFamily: SYSTEM_FONT,
    fontSize: 13,
    fontWeight: '600',
    letterSpacing: 0.2,
    opacity: 0.8,
  },
  indicator: {
    marginTop: 12,
    width: 4,
    height: 4,
    borderRadius: 2,
    opacity: 0.6,
  }
});
