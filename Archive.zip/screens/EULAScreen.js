/**
 * EULAScreen — End User License Agreement
 * Velvet Glass & Apple Editorial High-End Updates Integrated.
 * Palette: Deep Crimson, Obsidian, Liquid Silver (Strictly No Gold).
 */

import React, { useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Linking,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import Icon from '../components/Icon';
import { selection } from '../utils/haptics';
import { useTheme } from '../context/ThemeContext';
import { SUPPORT_EMAIL, SUPPORT_RESPONSE_TIME } from '../config/constants';
import EditorialScreenScaffold from '../components/EditorialScreenScaffold';

const SYSTEM_FONT = Platform.select({ ios: 'System', android: 'Roboto' });

const APPLE_EULA_URL = 'https://www.apple.com/legal/internet-services/itunes/dev/stdeula/';

const EULAScreen = ({ navigation }) => {
  const { colors, isDark } = useTheme();

  // High-End Color Logic (No Gold)
  const theme = useMemo(() => ({
    crimson: '#D2121A',
    silver: isDark ? '#E5E5E7' : '#8E8E93',
    obsidian: '#0A0A0C',
    glass: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.03)',
    glassBorder: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.05)',
  }), [isDark]);

  const styles = useMemo(() => createStyles(colors, isDark, theme), [colors, isDark, theme]);

  return (
    <EditorialScreenScaffold
      navigation={navigation}
      headerTitle="EULA"
      onBack={() => {
        selection();
        navigation.goBack();
      }}
      scroll={false}
    >
      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
          {/* Editorial Header Block */}
          <Animated.View entering={FadeIn.duration(800)} style={styles.introSection}>
            <Text style={[styles.headerEye, { color: theme.crimson }]}>LICENSE AGREEMENT</Text>
            <Text style={[styles.title, { color: colors.text }]}>EULA</Text>
            <Text style={[styles.date, { color: colors.textMuted || 'gray' }]}>
              Effective: April 6, 2026
            </Text>
            <Text style={[styles.intro, { color: colors.text }]}>
              Between Us is licensed to you subject to the terms of the Licensed Application End User License
              Agreement ("Standard EULA") set forth by Apple Inc., as modified by the supplemental
              terms below.
            </Text>
          </Animated.View>

          <Animated.View entering={FadeInDown.delay(200).duration(800)} style={styles.documentBody}>
            {/* Apple Standard EULA */}
            <View style={[styles.section, { borderTopColor: theme.glassBorder }]}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>
                Apple's Standard EULA
              </Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                Between Us is subject to Apple's Standard Licensed Application End User License Agreement,
                which is available at:
              </Text>
              <TouchableOpacity
                onPress={() => Linking.openURL(APPLE_EULA_URL)}
                activeOpacity={0.7}
                style={{ marginBottom: 16 }}
              >
                <Text style={[styles.link, { color: theme.crimson }]}>
                  {APPLE_EULA_URL}
                </Text>
              </TouchableOpacity>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                The Standard EULA governs your use of the app and is incorporated into this agreement
                by reference. In the event of a conflict between this document and the Standard EULA,
                the Standard EULA shall prevail.
              </Text>
            </View>

            {/* Supplemental Terms */}
            <View style={[styles.section, { borderTopColor: theme.glassBorder }]}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>
                Supplemental Terms
              </Text>

              <Text style={[styles.subTitle, { color: colors.text }]}>1. License Scope</Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                Subject to your compliance with these terms and the Standard EULA, we grant you a limited,
                non-exclusive, non-transferable, revocable license to download, install, and use Between Us
                on any Apple-branded device that you own or control, as permitted by the App Store Terms of Service.
              </Text>

              <Text style={[styles.subTitle, { color: colors.text }]}>2. Age Restriction</Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                You must be at least 18 years old to use Between Us. By using the app, you confirm that you
                meet this age requirement.
              </Text>

              <Text style={[styles.subTitle, { color: colors.text }]}>3. Content & Intellectual Property</Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                All prompts, designs, features, and app content are the intellectual property of Between Us.
                You retain ownership of your personal content (journal entries, responses, love notes, etc.).
                You may not copy, modify, distribute, or reverse engineer any part of the app.
              </Text>

              <Text style={[styles.subTitle, { color: colors.text }]}>4. Subscriptions</Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                Between Us offers optional in-app subscriptions (monthly and yearly). Payment is
                charged to your Apple ID account. Subscriptions auto-renew unless turned off at least 24
                hours before the end of the current period. You can manage subscriptions in Settings {'>'} Apple
                ID {'>'} Subscriptions on your device.
              </Text>

              <Text style={[styles.subTitle, { color: colors.text }]}>5. Privacy & Data</Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                Your use of Between Us is also governed by our Privacy Policy, available in the app
                under Settings {'>'} Safety & Support {'>'} Privacy Policy. Shared synced intimate content is encrypted before sync,
                some private content remains device-encrypted only, and we never sell your personal data.
              </Text>

              <Text style={[styles.subTitle, { color: colors.text }]}>6. Disclaimer</Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                Between Us is designed for thriving couples only. It is not a substitute for professional
                therapy, counseling, or medical advice. It is not appropriate for couples navigating trust
                breakdowns, abuse, or considering separation. If your relationship needs professional
                support, please seek qualified help.
              </Text>

              <Text style={[styles.subTitle, { color: colors.text }]}>7. Limitation of Liability</Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                To the maximum extent permitted by applicable law, Between Us and its developers shall not
                be liable for any indirect, incidental, special, consequential, or punitive damages, or any
                loss of profits or revenues, whether incurred directly or indirectly. Our total aggregate
                liability shall not exceed the amount you actually paid for the app in the twelve (12) months
                preceding the claim.
              </Text>

              <Text style={[styles.subTitle, { color: colors.text }]}>8. Termination</Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                This license is effective until terminated. Your rights under this license will terminate
                automatically if you fail to comply with any of its terms. Upon termination, you must cease
                all use of the app and delete all copies from your devices.
              </Text>

              <Text style={[styles.subTitle, { color: colors.text }]}>9. Governing Law</Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray' }]}>
                If you have a dispute or concern about the app, contact us first so we can try to resolve it
                informally. Any formal dispute handling is subject to applicable law, Apple's Standard EULA,
                and the current Terms of Service.
              </Text>

              <Text style={[styles.subTitle, { color: colors.text }]}>10. Contact</Text>
              <Text style={[styles.paragraph, { color: colors.textMuted || 'gray', marginBottom: 20 }]}>
                If you have questions about this EULA:{'\n\n'}
                Email: {SUPPORT_EMAIL}{'\n'}
                Response time: {SUPPORT_RESPONSE_TIME}
              </Text>
            </View>
          </Animated.View>

          {/* Velvet Glass Related Documents Card */}
          <Animated.View entering={FadeInDown.delay(400).duration(800)}>
            <BlurView intensity={isDark ? 30 : 50} tint={isDark ? "dark" : "light"} style={[styles.relatedCard, { borderColor: theme.glassBorder }]}>
              <Text style={[styles.relatedTitle, { color: colors.text }]}>Related Documents</Text>
              <TouchableOpacity onPress={() => navigation.navigate('Terms')} activeOpacity={0.7}>
                <View style={styles.relatedRow}>
                  <Text style={[styles.relatedLink, { color: colors.text }]}>Terms of Service</Text>
                  <Icon name="chevron-forward" size={18} color={colors.textMuted || 'gray'} />
                </View>
              </TouchableOpacity>
              <View style={[styles.relatedDivider, { backgroundColor: theme.glassBorder }]} />
              <TouchableOpacity onPress={() => navigation.navigate('PrivacyPolicy')} activeOpacity={0.7}>
                <View style={styles.relatedRow}>
                  <Text style={[styles.relatedLink, { color: colors.text }]}>Privacy Policy</Text>
                  <Icon name="chevron-forward" size={18} color={colors.textMuted || 'gray'} />
                </View>
              </TouchableOpacity>
              <View style={[styles.relatedDivider, { backgroundColor: theme.glassBorder }]} />
              <TouchableOpacity onPress={() => Linking.openURL(APPLE_EULA_URL)} activeOpacity={0.7}>
                <View style={styles.relatedRow}>
                  <Text style={[styles.relatedLink, { color: colors.text }]}>Apple Standard EULA</Text>
                  <Icon name="open-outline" size={18} color={colors.textMuted || 'gray'} />
                </View>
              </TouchableOpacity>
            </BlurView>
          </Animated.View>

          <View style={{ height: 100 }} />
      </ScrollView>
    </EditorialScreenScaffold>
  );
};

const createStyles = (colors, isDark, theme) => StyleSheet.create({
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 24, paddingBottom: 120 },

  introSection: { marginBottom: 30 },
  headerEye: {
    fontFamily: SYSTEM_FONT,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 2,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  title: {
    fontFamily: SYSTEM_FONT,
    fontSize: 42,
    fontWeight: '900',
    letterSpacing: -1.5,
    marginBottom: 8,
  },
  date: {
    fontFamily: SYSTEM_FONT,
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: 0.5,
    marginBottom: 24,
    textTransform: 'uppercase',
  },
  intro: {
    fontFamily: SYSTEM_FONT,
    fontSize: 17,
    lineHeight: 26,
    fontWeight: '500',
    opacity: 0.9,
  },

  documentBody: {
    paddingBottom: 20,
  },
  section: {
    borderTopWidth: 1,
    paddingTop: 32,
    marginTop: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontFamily: SYSTEM_FONT,
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.5,
    marginBottom: 16,
  },
  subTitle: {
    fontFamily: SYSTEM_FONT,
    fontSize: 17,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },
  paragraph: {
    fontFamily: SYSTEM_FONT,
    fontSize: 15,
    lineHeight: 24,
    fontWeight: '500',
    marginBottom: 16,
    opacity: 0.85,
  },
  link: {
    fontFamily: SYSTEM_FONT,
    fontSize: 15,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },

  relatedCard: {
    borderRadius: 28,
    borderWidth: 1.5,
    padding: 24,
    overflow: 'hidden',
    marginTop: 10,
  },
  relatedTitle: {
    fontFamily: SYSTEM_FONT,
    fontSize: 14,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 20,
    opacity: 0.8,
  },
  relatedRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  relatedLink: {
    fontFamily: SYSTEM_FONT,
    fontSize: 16,
    fontWeight: '700',
  },
  relatedDivider: {
    height: 1,
    width: '100%',
    marginVertical: 4,
  },
});

export default EULAScreen;
