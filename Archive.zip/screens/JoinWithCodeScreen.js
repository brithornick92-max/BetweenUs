import React, { useState, useRef, useMemo } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Modal,
  ActivityIndicator,
  Platform,
  KeyboardAvoidingView,
  Keyboard,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from '../components/Icon';
import { notification, NotificationFeedbackType } from '../utils/haptics';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import CoupleKeyService from '../services/security/CoupleKeyService';
import { recoverExistingInviteCodeLink } from '../services/linking/InviteCodeLinking';
import { joinWithInviteCode } from '../services/linking/CoupleLinkingService';
import { STORAGE_KEYS, storage } from '../utils/storage';
import { TYPOGRAPHY, SPACING, BORDER_RADIUS, SYSTEM_FONT } from '../utils/theme';

/**
 * JoinWithCodeScreen — lets the receiving partner enter an invite code
 * to join their partner's couple and derive the shared
 * encryption key via X25519 key exchange.
 */
export default function JoinWithCodeScreen({ navigation }) {
  const { colors } = useTheme();
  const { user, updateProfile } = useAuth();

  const [code, setCode] = useState('');
  const [phase, setPhase] = useState('input'); // input | joining | done | error
  const [statusMsg, setStatusMsg] = useState('');
  const [showPairedGuard, setShowPairedGuard] = useState(false);
  const inputRef = useRef(null);
  const guardResolveRef = useRef(null);
  const joinInFlightRef = useRef(false);

  const styles = useMemo(() => createStyles(colors), [colors]);

  const handleJoin = async () => {
    if (joinInFlightRef.current || phase === 'joining') return;
    Keyboard.dismiss();
    const trimmed = code.trim();
    if (!trimmed) {
      Alert.alert('Enter a code', 'Paste or type the invite code your partner shared.');
      return;
    }
    joinInFlightRef.current = true;

    // Guard: warn if already paired to prevent accidental re-pair
    const existingCouple = await storage.get(STORAGE_KEYS.COUPLE_ID, null);
    if (existingCouple) {
      const proceed = await new Promise((resolve) => {
        guardResolveRef.current = resolve;
        setShowPairedGuard(true);
      });
      if (!proceed) return;
    }

    setPhase('joining');
    setStatusMsg('Connecting...');

    try {
      const result = await joinWithInviteCode({
        code: trimmed,
        userId: user?.id ?? user?.uid,
        updateProfile,
        onStatus: setStatusMsg,
      });

      if (!result) {
        setPhase('error');
        return;
      }

      notification(NotificationFeedbackType.Success);
      setPhase('done');
      setStatusMsg('Linked successfully!');

      Alert.alert(
        'You\'re linked! 💕',
        'You and your partner are now connected on Between Us.',
        [{ text: 'Let\'s go!', onPress: () => navigation.goBack() }]
      );
    } catch (error) {
      notification(NotificationFeedbackType.Error);
      const msg = String(error?.message || '');
      if (msg.includes('Supabase is not configured')) {
        setStatusMsg("Sync isn't available in this build.");
      } else if (msg.includes('duplicate key') || msg.includes('already exists')) {
        try {
          const resolvedCoupleId = await recoverExistingInviteCodeLink({
            userId: user?.id ?? user?.uid,
            updateProfile,
            myPublicKeyB64: await CoupleKeyService.getDevicePublicKeyB64(),
          });

          if (resolvedCoupleId) {
            setStatusMsg("You're already linked to this partner.");
            setPhase('done');
            setTimeout(() => navigation.goBack(), 1200);
            return;
          }
        } catch (_) {}

        setStatusMsg('Link may have failed. Please retry with a fresh code.');
      } else {
        setStatusMsg(msg || 'Unable to join. Check the code and try again.');
      }
      setPhase('error');
    } finally {
      joinInFlightRef.current = false;
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        pointerEvents="none"
        colors={[colors.background, colors.background]}
        style={StyleSheet.absoluteFill}
      />

      {/* ─── Already-paired guard modal ─── */}
      <Modal visible={showPairedGuard} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalBadge}>
              <Icon name="warning-outline" size={24} color={colors.primary} />
            </View>
            <Text style={styles.modalTitle}>Already paired</Text>
            <Text style={styles.modalBody}>
              You’re currently connected to a partner. Joining with a new code will replace your existing pairing for both of you.
            </Text>
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonSecondary]}
                onPress={() => { setShowPairedGuard(false); guardResolveRef.current?.(false); }}
              >
                <Text style={[styles.modalButtonPrimaryText, { color: colors.text }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonPrimary]}
                onPress={() => { setShowPairedGuard(false); guardResolveRef.current?.(true); }}
              >
                <Text style={styles.modalButtonPrimaryText}>Continue</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <SafeAreaView style={styles.safeArea} edges={['top', 'bottom']}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
            activeOpacity={0.8}
          >
            <Icon name="arrow-back-outline" size={24} color={colors.text} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Join Partner</Text>
          <View style={styles.headerSpacer} />
        </View>

        <KeyboardAvoidingView
          style={styles.body}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <View style={styles.card}>
            {/* Icon */}
            <View style={styles.iconWrap}>
              <Icon
                name={phase === 'done' ? 'heart-outline' : 'infinite-outline'}
                size={36}
                color={phase === 'done' ? colors.primary : colors.textMuted}
              />
            </View>

            <Text style={styles.title}>
              {phase === 'done' ? 'You\'re linked!' : 'Enter Invite Code'}
            </Text>
            <Text style={styles.subtitle}>
              {phase === 'done'
                ? 'Your private space is ready.'
                : 'Paste the code your partner shared with you.'}
            </Text>

            {phase !== 'done' && (
              <TextInput
                ref={inputRef}
                style={styles.codeInput}
                placeholder="Paste invite code here"
                placeholderTextColor={colors.textMuted}
                value={code}
                onChangeText={setCode}
                autoCapitalize="none"
                autoCorrect={false}
                editable={phase === 'input' || phase === 'error'}
                returnKeyType="go"
                onSubmitEditing={handleJoin}
                accessibilityLabel="Invite code"
                accessibilityHint="Enter the invite code from your partner"
              />
            )}

            {statusMsg ? (
              <View style={styles.statusRow}>
                <Icon
                  name={
                    phase === 'done'
                      ? 'check-circle'
                      : phase === 'error'
                      ? 'alert-circle'
                      : 'loading'
                  }
                  size={18}
                  color={
                    phase === 'done'
                      ? colors.primary
                      : phase === 'error'
                      ? '#C8605A'
                      : colors.textMuted
                  }
                />
                <Text
                  style={[
                    styles.statusText,
                    phase === 'error' && { color: '#C8605A' },
                    phase === 'done' && { color: colors.primary },
                  ]}
                >
                  {statusMsg}
                </Text>
              </View>
            ) : null}

            {(phase === 'input' || phase === 'error') && (
              <TouchableOpacity
                style={[styles.joinButton, !code.trim() && styles.joinButtonDisabled]}
                onPress={handleJoin}
                disabled={!code.trim()}
                activeOpacity={0.9}
              >
                <Text style={styles.joinButtonText}>Link Up</Text>
              </TouchableOpacity>
            )}

            {phase === 'joining' && (
              <ActivityIndicator
                style={{ marginTop: SPACING.lg }}
                color={colors.primary}
                size="large"
              />
            )}
          </View>

          <Text style={styles.note}>
            Your encryption keys never leave this device.
          </Text>
        </KeyboardAvoidingView>
      </SafeAreaView>

    </View>
  );
}

const createStyles = (colors) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    safeArea: { flex: 1 },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: SPACING.lg,
      paddingVertical: SPACING.md,
    },
    backButton: {
      width: 40,
      height: 40,
      borderRadius: 20,
      alignItems: 'center',
      justifyContent: 'center',
    },
    headerTitle: {
      fontFamily: SYSTEM_FONT,
      fontSize: 36,
      fontWeight: '900',
      letterSpacing: -1,
      lineHeight: 42,
      flex: 1,
      textAlign: 'center',
      color: colors.text,
    },
    headerSpacer: { width: 40 },
    body: {
      flex: 1,
      paddingHorizontal: SPACING.xl,
      justifyContent: 'center',
    },
    card: {
      backgroundColor: colors.surface,
      borderRadius: BORDER_RADIUS.xl,
      padding: SPACING.xl,
      borderWidth: 1,
      borderColor: colors.border,
      alignItems: 'center',
    },
    iconWrap: {
      width: 72,
      height: 72,
      borderRadius: 36,
      backgroundColor: colors.primary + '15',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: SPACING.lg,
    },
    title: {
      ...TYPOGRAPHY.h2,
      fontSize: 22,
      fontWeight: '700',
      color: colors.text,
      textAlign: 'center',
      marginBottom: SPACING.sm,
    },
    subtitle: {
      ...TYPOGRAPHY.body,
      color: colors.textMuted,
      textAlign: 'center',
      marginBottom: SPACING.lg,
      lineHeight: 22,
    },
    codeInput: {
      width: '100%',
      backgroundColor: colors.background,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: BORDER_RADIUS.md,
      paddingHorizontal: SPACING.md,
      paddingVertical: SPACING.md,
      color: colors.text,
      fontSize: 16,
      textAlign: 'center',
      fontWeight: '500',
    },
    statusRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: SPACING.md,
      gap: 8,
    },
    statusText: {
      ...TYPOGRAPHY.body,
      color: colors.textMuted,
      fontSize: 14,
    },
    joinButton: {
      marginTop: SPACING.lg,
      backgroundColor: colors.primary,
      paddingVertical: 16,
      paddingHorizontal: 40,
      borderRadius: 40,
      alignItems: 'center',
      width: '100%',
    },
    joinButtonDisabled: {
      opacity: 0.4,
    },
    joinButtonText: {
      color: '#FFFFFF',
      fontSize: 16,
      fontWeight: '700',
      letterSpacing: 0.5,
    },
    note: {
      ...TYPOGRAPHY.body,
      color: colors.textMuted,
      textAlign: 'center',
      marginTop: SPACING.lg,
      fontSize: 13,
      opacity: 0.6,
    },
    modalOverlay: {
      flex: 1,
      backgroundColor: 'rgba(0,0,0,0.6)',
      justifyContent: 'center',
      padding: SPACING.xl,
    },
    modalCard: {
      backgroundColor: colors.surface,
      borderRadius: BORDER_RADIUS.xl,
      borderWidth: 1,
      borderColor: colors.border,
      padding: SPACING.xl,
      alignItems: 'center',
    },
    modalBadge: {
      width: 44,
      height: 44,
      borderRadius: 22,
      backgroundColor: colors.primary + '15',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: SPACING.md,
    },
    modalTitle: {
      ...TYPOGRAPHY.h2,
      color: colors.text,
      fontSize: 20,
      fontWeight: '700',
      textAlign: 'center',
      marginBottom: SPACING.sm,
    },
    modalBody: {
      ...TYPOGRAPHY.body,
      color: colors.textMuted,
      textAlign: 'center',
      marginBottom: SPACING.lg,
      lineHeight: 22,
    },
    modalInput: {
      width: '100%',
      backgroundColor: colors.background,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: BORDER_RADIUS.md,
      paddingHorizontal: SPACING.md,
      paddingVertical: SPACING.md,
      color: colors.text,
      fontSize: 16,
      marginBottom: SPACING.lg,
    },
    modalActions: {
      width: '100%',
      flexDirection: 'row',
      gap: SPACING.sm,
    },
    modalButton: {
      flex: 1,
      borderRadius: 40,
      minHeight: 52,
      alignItems: 'center',
      justifyContent: 'center',
    },
    modalButtonPrimary: {
      backgroundColor: colors.primary,
    },
    modalButtonSecondary: {
      backgroundColor: colors.background,
      borderWidth: 1,
      borderColor: colors.border,
    },
    modalButtonPrimaryText: {
      color: '#FFFFFF',
      fontSize: 16,
      fontWeight: '700',
    },
    modalButtonSecondaryText: {
      color: colors.text,
      fontSize: 16,
      fontWeight: '600',
    },
  });
