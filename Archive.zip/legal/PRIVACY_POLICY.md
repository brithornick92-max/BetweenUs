# Privacy Policy

**Last Updated: April 6, 2026**

At Between Us, your privacy is our top priority. This Privacy Policy explains how we collect, use, protect, and share your information when you use our app.

---

## Our Privacy Commitment

**We believe your intimate moments should stay private.** That's why we:
- ✅ Use end-to-end encryption for sensitive content (journals, prompts, intimate answers)
- ✅ Never sell your personal data
- ✅ Never share your content with advertisers or data brokers
- ✅ Process data on your device whenever possible
- ✅ Give you full control over your data

---

## 1. Information We Collect

### 1.1 Information You Provide

**Account Information:**
- Email address
- Display name
- Partner names (what you call each other)
- Relationship start date (optional)

**Content You Create:**
- Journal entries and responses to prompts
- Shared memories and milestones
- Love notes (text and optional photo attachments)
- Optional encrypted voice notes
- Inside jokes, nicknames, and shared references
- Custom rituals and preferences
- Heat level and energy level preferences
- Relationship climate selections (e.g., connected, playful, calm)
- Soft boundary settings (hidden categories, paused content)
- Calendar events (title, date, time, optional location, notes)
- Vibe signal selections (e.g., passionate, tender, adventurous)
- Relationship duration

**Usage Preferences:**
- Content filtering preferences
- Notification settings
- App customization choices
- Voice note permission choices

### 1.2 Information Collected Automatically

**Device Information:**
- Device type and model
- Operating system version
- App version
- App and authentication identifiers used by our infrastructure

**Usage Data:**
- Features you use
- Prompts you respond to (tracked locally for deduplication)
- Daily usage counts (prompts viewed, dates viewed)
- Error logs and crash reports

### 1.3 Information We Don't Collect

We **never** collect:
- ❌ Your sexual orientation
- ❌ Precise location data
- ❌ Contact lists
- ❌ Photos or media (unless you explicitly share)
- ❌ Biometric data (we use Face ID/Touch ID for app lock via your device's built-in authentication, but no biometric data is collected, stored, or transmitted by Between Us — authentication happens entirely within your device's secure hardware)
- ❌ Financial information (handled by app stores)

---

## 2. How We Use Your Information

### 2.1 To Provide the Service
- Display personalized prompts based on relationship duration
- Sync data between you and your partner
- Save your journal entries and responses
- Send notifications (if enabled): daily prompt reminders, partner activity alerts, weekly relationship recaps, and milestone celebrations
- Collect limited pseudonymous analytics events (such as screen views, paywall events, feature usage, and exports) to improve the app
- Provide customer support

### 2.2 To Improve the Service
- Fix bugs and improve performance
- Develop new features
- Optimize user experience

### 2.3 To Communicate With You
- Send important service updates
- Respond to your support requests
- Send account, billing, and support-related messages

### 2.4 For Security and Compliance
- Prevent fraud and abuse
- Enforce our Terms of Service
- Comply with legal obligations
- Protect user safety
- Maintain service security

---

## 3. Data Security and Encryption

### 3.1 End-to-End Encryption (Couple Key)
**Shared synced content is protected with E2EE:**
- Shared journal entries, prompt responses, memories, and love notes are encrypted on your device before upload
- Only you and your linked partner can decrypt couple-encrypted content
- We cannot read content protected by your couple encryption key
- Encryption keys are derived via X25519 key exchange during partner pairing and never stored on our servers
- Partner pairing uses a one-time linking payload and device public keys rather than personal profile data

### 3.2 Device-Level Encryption
**Additional local data is encrypted with a device-specific key:**
- Daily check-ins (mood, closeness, and notes)
- Local-only memories and milestones
- Inside jokes and shared references
- Relationship climate selections

This data is encrypted on your device using a key stored in your device's secure Keychain. It cannot be read by extracting the app's storage files.

This data is encrypted on your device using a key stored in your device's secure Keychain and is intended to protect local data at rest.

**Note:** Some metadata (such as timestamps, event types, mood labels, heat-level preferences, calendar scheduling fields, and push tokens when notifications are enabled) is stored without end-to-end encryption so we can provide features like filtering, sorting, delivery, and scheduling. This metadata is still protected by TLS in transit and access controls at rest.

### 3.3 Security Measures
We implement industry-standard security:
- TLS/SSL encryption for data in transit
- Client-side encryption using XSalsa20-Poly1305 (NaCl secretbox)
- Encrypted storage at rest by our cloud provider
- Secure authentication protocols
- Access controls and monitoring

### 3.4 Device-Only Data
**The following data is stored exclusively on your device and never uploaded:**
- Soft boundary settings (hidden categories, paused content)
- Energy level and relationship climate selections
- Inside jokes and shared references
- Year reflection narratives
- Content preference history (This or That choices, prompt engagement)
- Welcome back and return-detection timestamps
- Biometric vault key (stored in device secure hardware)

### 3.5 Client-Side Processing
**Privacy by design:**
- Personalization and content recommendations are processed on your device
- No intimate content is sent to servers for analysis
- Prompt selection, energy matching, and filtering happen locally
- Your preference data stays on your device
- Surprise Tonight and content personalization algorithms run locally

---

## 4. Data Sharing and Disclosure

### 4.1 With Your Partner
- Content you choose to share is visible to your linked partner
- Vibe signals and moment signals are sent to your linked partner as connectivity allows
- Prompt responses can be shared via the Reveal Together feature (both partners must opt in)
- You control what you share and when
- Your partner cannot access your private entries or soft boundary settings
- Unlinking stops new data sharing and removes access to the shared couple space

### 4.2 With Service Providers
We work with trusted partners who help us operate:
- **Cloud hosting:** Supabase (journal content is E2E encrypted; metadata such as timestamps, mood labels, and couple IDs is stored with standard server-side encryption)
- **Subscription management:** RevenueCat (subscription status, entitlement IDs, and app user identifiers — no personal content)
- **Error monitoring:** Sentry (crash reports, performance traces, limited session replays, and optional user feedback to diagnose bugs)
- **Payment processing:** Handled by Apple (we don't see payment details)
- **Customer support:** Only if you contact us

These providers process data under their own terms and applicable agreements with us.

### 4.3 We Never Share
We **never** sell or share your data with:
- ❌ Advertisers
- ❌ Data brokers
- ❌ Marketing companies
- ❌ Social media platforms
- ❌ Third-party apps

### 4.4 Legal Requirements
We may disclose information if required by law:
- Valid court orders or subpoenas
- Legal process or government requests
- To protect rights, property, or safety
- To prevent fraud or abuse

We'll notify you unless legally prohibited.

---

## 5. Your Privacy Rights

### 5.1 Access Your Data
- View all your data in the app
- Export your data (journal entries, prompt answers, memories, rituals, check-ins, vibes, and love notes)
- Download your account information
- Request a copy of your data

### 5.2 Control Your Data
- Edit or delete entries anytime
- Unlink from your partner
- Change privacy settings
- Configure soft boundaries to hide content categories

### 5.3 Delete Your Data
- Delete individual entries
- Delete your entire account
- Request complete data deletion
- Deletion is permanent, but backup copies may persist for a limited period before routine purge

### 5.4 Opt-Out Rights
- Disable notifications
- Decline optional data collection (e.g., relationship start date)

### 5.5 Regional Rights
**For EU/UK users (GDPR):**
- Right to access
- Right to rectification
- Right to erasure
- Right to data portability
- Right to object
- Right to restrict processing

**For California users (CCPA):**
- Right to know
- Right to delete
- Right to opt-out of sale (we don't sell data)
- Right to non-discrimination

---

## 6. Data Retention

### 6.1 Active Accounts
- We retain your data while your account is active
- You can delete data anytime
- Deleted data is removed from active systems promptly; backup copies may persist for a limited period before routine purge

### 6.2 Deleted Accounts
- Account deletion is permanent
- Most active data is deleted promptly
- Some data may be retained for legal compliance or fraud prevention for a limited period
- Backup copies may persist for a limited period before routine purge

### 6.3 Partner Data
- Your partner's data remains separate
- Deleting your account doesn't affect their data
- Account deletion removes your access and ends future sharing from your account

---

## 7. Children's Privacy

Between Us is **not for children:**
- You must be 18+ to use the app
- We don't knowingly collect data from minors
- If we discover underage use, we delete the account
- Parents: Please monitor your children's device usage

---

## 8. International Data Transfers

- Our app and service providers may process data in the United States and other countries where they operate
- Data may be transferred internationally when required to provide the service
- Transfer protections depend on the provider, the destination country, and applicable law

---

## 9. Third-Party Services

### 9.1 Services We Use
- **Supabase:** Encrypted data storage and authentication
- **RevenueCat:** Subscription management
- **Sentry:** Crash reporting, performance monitoring, limited session replays (10% of sessions; 100% of sessions where an error occurs), and optional user feedback submission
- **Expo:** Push notification delivery and over-the-air updates
- **Apple:** Payment processing and app distribution

### 9.2 Their Privacy Policies
- [Supabase Privacy Policy](https://supabase.com/privacy)
- [RevenueCat Privacy Policy](https://www.revenuecat.com/privacy)
- [Sentry Privacy Policy](https://sentry.io/privacy/)
- [Expo Privacy Policy](https://expo.dev/privacy)
- [Apple Privacy Policy](https://www.apple.com/privacy/)

---

## 10. Changes to This Policy

- We may update this policy from time to time
- Material changes will be notified via email or app
- Continued use means you accept changes
- Previous versions available upon request

---

## 11. Your Choices

### You Control Your Privacy:

**Minimize Data Collection:**
- Skip optional fields (e.g., relationship start date)
- Disable notifications

**Protect Your Account:**
- Use a strong, unique password
- Enable device security (passcode, biometrics)
- Don't share your login credentials

**Manage Sharing:**
- Choose what to share with your partner
- Keep entries private
- Unlink when needed

---

## 12. Contact Us

**Privacy Questions:**
- Email: brittanyapps@outlook.com
- Support: brittanyapps@outlook.com

**Data Requests:**
- Email: brittanyapps@outlook.com
- Include: Your email and request type

**Email:**
Between Us Privacy Team  
brittanyapps@outlook.com

**Response Time:** We respond within 30 days

---

## 13. Transparency Report

We aim to communicate material privacy and security changes through updated legal documents, in-app notices, or direct support responses when appropriate.

---

## 14. Privacy by Design

**Our Principles:**

1. **Data Minimization:** We only collect what's necessary
2. **Purpose Limitation:** Data used only for stated purposes
3. **Storage Limitation:** Data deleted when no longer needed
4. **Accuracy:** You can correct your data anytime
5. **Integrity:** Strong security measures protect your data
6. **Confidentiality:** End-to-end encryption for intimate content
7. **Accountability:** We're responsible for protecting your privacy

---

## Summary

**What we do:**
✅ Encrypt your intimate content  
✅ Process data on your device  
✅ Give you full control  
✅ Never sell your data  
✅ Respect your privacy  

**What we don't do:**
❌ Sell your data  
❌ Share with advertisers  
❌ Track you across apps  
❌ Read your encrypted content  
❌ Collect unnecessary information  

---

**Your privacy matters to us. If you have any questions or concerns, please reach out.**

*Last Updated: April 6, 2026*
