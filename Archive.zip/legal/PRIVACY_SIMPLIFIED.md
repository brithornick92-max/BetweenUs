# Privacy in Plain English

**Your privacy matters. Here's what you need to know.**

---

## 🔒 Your Data is Protected

### What We Encrypt (End-to-End)
✅ Your journal entries
✅ Your responses to prompts
✅ Shared love notes and photo attachments
✅ Shared memories and milestones

### What We Encrypt (Device-Level)
✅ Daily check-ins (mood, closeness, notes)
✅ Local-only memories
✅ Inside jokes and shared references
✅ Relationship climate selections

### What We Don't Encrypt (But Still Protect)
⚠️ Metadata like timestamps, mood labels, and heat-level preferences  
⚠️ Calendar events and date plans  
⚠️ Nickname and tone settings  

**Why:** Metadata isn’t encrypted so the app can filter, sort, and display your content. It’s still protected by access controls and standard server encryption — just not end-to-end.

**How E2EE works:** Your journal entries are encrypted on your device before upload. Only you and your partner can read them. Not even we can see them.

---

## 🚫 What We Never Do

❌ **Sell your data** - Never. Not to anyone.  
❌ **Share with advertisers** - Your intimate moments aren't for sale.  
❌ **Track you across apps** - We only care about Between Us.  
❌ **Read your journal** - It's encrypted. We literally can't.  
❌ **Ask about your orientation** - Love is love. That's all we need to know.
❌ **Store your biometrics** - Face ID/Touch ID runs on your device's hardware only.

---

## ✅ What We Do

### We Collect (Only What's Needed)
- Your email (to log you in)
- Partner names (what you call each other)
- Relationship start date (optional, for better prompts)
- Your responses and shared content (encrypted where supported)
- Daily usage counts (for free-tier limits)
- Limited analytics, crash, and performance data to improve reliability

### We Use It To
- Show you personalized prompts
- Sync with your partner
- Improve the app
- Fix bugs
- Send you notifications (if you want them)

### What Never Leaves Your Device
- Soft boundary settings (hidden categories, paused prompts)
- Energy level and relationship climate choices
- Inside jokes and shared references
- Year reflection narratives
- Content preference history
- Biometric vault key

### We Process On Your Device
- Personalization and prompt selection happen on your phone
- Energy matching and content recommendations run locally
- Your preference data stays on your device
- Privacy by design

---

## 👥 Sharing With Your Partner

### You Control Everything
- Choose what to share
- Keep entries private
- Delete anytime
- Unlink when needed

### Your Partner Can See
- Only what you choose to share
- Your Vibe Signals and Moment Signals (when you send them)
- Revealed prompt answers (only when both opt in)
- Nothing private
- No new shared activity after you unlink

### Your Partner Cannot See
- Your private entries
- Your soft boundary settings
- Your deleted content
- Your account password
- Your payment info

---

## 🗑️ Deleting Your Data

### You Can Delete
- Individual entries (anytime)
- Your entire account (permanent)
- Shared content (removes for both)
- Everything (no questions asked)

### What Happens
- Removed from active systems promptly
- Backup copies may persist for a limited period before routine purge
- Cannot be recovered after deletion finishes processing
- Your partner's data stays separate

---

## 🛡️ Your Rights

### You Can
✅ See all your data
✅ Export your journal
✅ Delete everything
✅ Control notifications  

### We Must
✅ Protect your data  
✅ Respect your choices  
✅ Be transparent  
✅ Honor the rights described in our policies  
✅ Respond to your requests  

---

## 🌍 Privacy Laws

We provide privacy-rights disclosures for:
- **GDPR** (Europe)
- **CCPA** (California)
- Adult-only use (18+)

---

## 📧 Questions?

**Privacy concerns:** brittanyapps@outlook.com  
**Data requests:** brittanyapps@outlook.com  
**General support:** brittanyapps@outlook.com

**We respond within 24-48 hours.**

---

## 🎯 Bottom Line

**Your intimate moments are yours.**

We built Between Us with privacy at the core. Your journal entries are encrypted, your data isn't sold, and you're always in control.

We make money from subscriptions, not from your data.

---

**Read the full Privacy Policy:** See PRIVACY_POLICY.md
**Last Updated:** April 6, 2026
