# Contact Information - Between Us

**Primary Contact:** brittanyapps@outlook.com

---

## All Inquiries

For the initial launch, all inquiries should be directed to:

**Email:** brittanyapps@outlook.com

This includes:
- General support questions
- Privacy inquiries
- Legal questions
- Data requests
- Safety concerns
- Feedback and suggestions
- Feature requests
- Press inquiries
- Business partnerships
- API access

---

## Response Times

**Target Response Time:** 24-48 hours

**Priority Issues:**
- Safety concerns: As soon as available
- Data deletion requests: Typically within 24-48 hours, depending on verification needs
- Privacy inquiries: Typically within 24-48 hours
- General support: Typically within 24-48 hours

---

## Future Email Structure

As the app grows, we may implement dedicated email addresses:

**Planned Structure:**
- support@betweenus.app - General support
- privacy@betweenus.app - Privacy inquiries
- legal@betweenus.app - Legal questions
- safety@betweenus.app - Safety concerns
- feedback@betweenus.app - User feedback

All will initially forward to: brittanyapps@outlook.com

---

## Social Media (Planned)

**Instagram:** @betweenus.app  
**Twitter:** @betweenus_app  
**Facebook:** /betweenusapp

*Note: Social media accounts to be created before launch*

---

## Mailing Address

*To be added when business entity is established*

---

## Support Hours

**Email Support:** Messages can be sent anytime (responses typically within 24-48 hours)  
**Timezone:** US Eastern (ET)

---

## Emergency Contact

For urgent safety concerns:
**Email:** brittanyapps@outlook.com  
**Subject Line:** URGENT - Safety Concern

---

## App Store Support

**Apple App Store:** Available on the App Store (search "Between Us")

---

**Last Updated:** April 6, 2026
